package weatherapp.tittojose.me.weatherapp.ui.presenter

interface HomePresenterContract {
	fun loadWeatherData()
	fun retryLoadWeatherData()
}