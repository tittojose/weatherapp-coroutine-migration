package weatherapp.tittojose.me.weatherapp.repository

import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import weatherapp.tittojose.me.weatherapp.model.WeatherAPI
import weatherapp.tittojose.me.weatherapp.model.pojo.WeatherModel
import weatherapp.tittojose.me.weatherapp.repository.WeatherRepositoryContract.WeatherLoadListener

class WeatherRepository(private val weatherAPI: WeatherAPI) : WeatherRepositoryContract {
	private var weatherLoadListener: WeatherLoadListener? = null
	override fun setWeatherLoadListener(weatherLoadListener: WeatherLoadListener) {
		this.weatherLoadListener = weatherLoadListener
	}

	override fun getWeatherData() {
		weatherAPI.weatherForecast!!.enqueue(object : Callback<WeatherModel?> {
			override fun onResponse(call: Call<WeatherModel?>, response: Response<WeatherModel?>) {
				if (response.isSuccessful) {
					weatherLoadListener!!.onWeatherDataLoadedSuccess(response.body())
				} else {
					weatherLoadListener!!.onWeatherDataLoadedFailed()
				}
			}

			override fun onFailure(call: Call<WeatherModel?>, t: Throwable) {
				weatherLoadListener!!.onWeatherDataLoadedFailed()
			}
		})
	}
}