package weatherapp.tittojose.me.weatherapp.ui.view

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import kotlinx.android.synthetic.main.layout_error.*
import kotlinx.android.synthetic.main.layout_loading.*
import kotlinx.android.synthetic.main.layout_weather.*
import weatherapp.tittojose.me.weatherapp.R
import weatherapp.tittojose.me.weatherapp.Utils
import weatherapp.tittojose.me.weatherapp.model.APIClient
import weatherapp.tittojose.me.weatherapp.model.pojo.WeatherModel
import weatherapp.tittojose.me.weatherapp.repository.WeatherRepository
import weatherapp.tittojose.me.weatherapp.repository.WeatherRepositoryContract
import weatherapp.tittojose.me.weatherapp.ui.presenter.HomeScreenPresenter

class HomeScreenActivity : AppCompatActivity(), HomeScreen {

	private var startRotateAnimation: Animation? = null
	private var homeScreenPresenter: HomeScreenPresenter? = null
	private var bottomUpAnimation: Animation? = null
	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.activity_home_screen)
		initializeAnimationObjects()
		val weatherRepositoryContract: WeatherRepositoryContract = WeatherRepository(APIClient.weatherAPIClient)
		homeScreenPresenter = HomeScreenPresenter(this, weatherRepositoryContract)
		homeScreenPresenter!!.loadWeatherData()
		btnRetry.setOnClickListener { onRetryButtonClicked() }
	}

	private fun initializeAnimationObjects() {
		startRotateAnimation = AnimationUtils.loadAnimation(applicationContext, R.anim.anim_rotate)
		bottomUpAnimation = AnimationUtils.loadAnimation(applicationContext, R.anim.anim_bottomsup)
	}

	override fun onWeatherDataLoadSuccess(weatherModel: WeatherModel) {
		layoutWeather.visibility = View.VISIBLE
		setCurrentWeatherData(weatherModel)
	}

	override fun onWeatherDataLoadFailed() {
		layoutError!!.visibility = View.VISIBLE
	}

	override fun showLoading() {
		layoutLoading.visibility = View.VISIBLE
		imgViewLoading.startAnimation(startRotateAnimation)
	}

	override fun hideLoading() {
		imgViewLoading!!.clearAnimation()
		layoutLoading!!.visibility = View.GONE
	}

	override fun onRetryButtonClicked() {
		homeScreenPresenter!!.retryLoadWeatherData()
	}

	private fun setCurrentWeatherData(weatherData: WeatherModel) {
		txtCurrentWeather!!.text = Utils.formatDegreeCelsiusData(weatherData.current.tempC)
		txtLocation!!.text = weatherData.location.locationName
	}
}