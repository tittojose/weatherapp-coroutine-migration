package weatherapp.tittojose.me.weatherapp.ui.presenter

import weatherapp.tittojose.me.weatherapp.model.pojo.WeatherModel
import weatherapp.tittojose.me.weatherapp.repository.WeatherRepositoryContract
import weatherapp.tittojose.me.weatherapp.repository.WeatherRepositoryContract.WeatherLoadListener
import weatherapp.tittojose.me.weatherapp.ui.view.HomeScreen

class HomeScreenPresenter(
	private val homeScreen: HomeScreen,
	private val weatherRepository: WeatherRepositoryContract
	) : HomePresenterContract {

	private val weatherLoadListener: WeatherLoadListener

	override fun loadWeatherData() {
		homeScreen.showLoading()
		weatherRepository.getWeatherData()
	}

	override fun retryLoadWeatherData() {
		loadWeatherData()
	}

	init {
		weatherLoadListener = object : WeatherLoadListener {
			override fun onWeatherDataLoadedSuccess(weatherModel: WeatherModel) {
				homeScreen.hideLoading()
				homeScreen.onWeatherDataLoadSuccess(weatherModel)
			}

			override fun onWeatherDataLoadedFailed() {
				homeScreen.hideLoading()
				homeScreen.onWeatherDataLoadFailed()
			}
		}
		weatherRepository.setWeatherLoadListener(weatherLoadListener)
	}
}