package weatherapp.tittojose.me.weatherapp

import kotlin.math.roundToInt

object Utils {
	fun formatDegreeCelsiusData(tempC: Float?): String {
		val tempInt = (tempC!!).roundToInt()
		return String.format("%s%s", tempInt, "\u2103")
	}
}